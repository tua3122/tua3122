//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import static java.lang.System.*;

public class Words
{
	private ArrayList<Word> words;

	public Words()
	{
		setWords("");
	}

	public Words(String wordList)
	{

	}

	public void setWords(String wordList)
	{





	}
	
	public int countWordsWithXChars(int size)
	{
		int count=0;





		return count;
	}
	
	//this method will remove all words with a specified size / length
	//this method will also return the sum of the vowels in all words removed
	public int removeWordsWithXChars(int size)
	{





		return 0;
	}

	public int countWordsWithXVowels(int numVowels)
	{
		int count=0;






		return count;
	}
	
	public String toString()
	{
	   return "";
	}
}