//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class Word
{
	private String word;
   private static String vowels = "AEIOUaeiou";   //only one

	public Word()
	{

	}

	public Word(String wrd)
	{

	}

	public void setWord(String wrd)
	{

	}
	
	public int getNumVowels()
	{
		int count=0;





		return count;
	}
	
	public int getLength()
	{
		return 0;
	}

	public String toString()
	{
	   return "";
	}
}