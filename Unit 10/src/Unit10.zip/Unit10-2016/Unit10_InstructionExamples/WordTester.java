//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class WordTester
{
	public static void main(String[] args)
	{
		//add test cases
		
		
		
		
		
		//add more test cases
		
		
		
		
		
	}
}