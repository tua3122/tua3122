//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class Lab01a
{
   public static void main(String args[])
   {
      //instantiate a StarsAndStripes object
      
      //call the methods needed to make the patterns on the word document
   }
}