public class Lab0a3
{
	public static void main ( String[] args )
	{
		System.out.println("Allen Tu \t  1 Febuary 2018 \t 1\n\n" );
		System.out.println("Fly (ascii-code.com)" );
		System.out.println("\n\n\n\n" );


		System.out.println("   !__!");
		System.out.println("  (@)(-)");
		System.out.println(" \\.'||'./");
		System.out.println("-:  ::  :-");
		System.out.println("/'..''..'\\" );
		//add other output

		System.out.println(" \n\n\n\nHelpFul Hints" );
		System.out.println("\\\\ draws one backslash on the screen!\n" );
		System.out.println("\\\" draws one double quote on the screen!\n" );
		System.out.println("\\\' draws one single quote on the screen!\n" );
	}
}