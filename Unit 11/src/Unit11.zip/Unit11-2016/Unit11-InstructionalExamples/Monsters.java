//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import java.util.Arrays;
import java.util.Scanner;
import static java.lang.System.*;
import static java.lang.Math.*;
import static java.util.Arrays.*;
import static java.util.Collections.*;

public class Monsters
{
	//use an ArrayList for extra credit!!!
	//private ArrayList<Monster> myMonsters;

	private Monster[] myMonsters;

	public Monsters()
	{
		setMonsters(0);
	}

	public Monsters(int size)
	{


	}
	
	public void setMonsters(int size)
	{
		//size the array
		
	}
	
	public void add(int spot, Monster m)
	{
		//put m in the Monster array at [spot]


	}
	
	public Monster get(int spot)
	{
		return null;
	}

	public Monster getLargest( )
	{
		//Arrays.sort() might be handy
		return null;
	}

	public Monster getSmallest( )
	{

		return null;
	}

	public String toString()
	{
		return "";
	}
}