//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;
import java.util.Arrays;
import java.util.Scanner;

public class ArrayStats
{
	//instance variable
	
	//constructor
	
	//set method
	
	
	public int getNumGroupsOfSize(int size)
	{
		int cnt=0;





		return cnt;
	}
	
	public String toString()
	{
		return ""+Arrays.toString(array);
	}
}