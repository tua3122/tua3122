//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import java.util.Scanner;

public class Histogram
{
	private int[] numCount;

	//constructor 

	//set method

	//toString method
}