//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import java.util.Scanner;

public class OddsAndEvens
{
	private static int countEm(int[] array, boolean odd)
	{
		return 0;
	}
	
	public static int[] getAllEvens(int[] array)
	{
		return null;
	}

	public static int[] getAllOdds(int[] array)
	{
		return null;		
	}
}