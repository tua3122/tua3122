//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

public class Average
{
	//instance variables
	private double one, two, average;

	public void setNums(double num1, double num2)
	{


	}

	public void average( )
	{
		double sum=0;

	}
	public void print( )
	{



	}
}