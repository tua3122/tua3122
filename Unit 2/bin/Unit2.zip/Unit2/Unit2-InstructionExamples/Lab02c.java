//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

public class Lab02c
{
	public static void main( String[] args )
   {
 		//add more test cases
	}
}