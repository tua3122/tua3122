//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

public class Cube
{
	private int side;
	private int surfaceArea;

	public void setSide(int s)
	{
	}

	public void calculateSurfaceArea( )
	{
	}

	public void print( )
	{
	}
}