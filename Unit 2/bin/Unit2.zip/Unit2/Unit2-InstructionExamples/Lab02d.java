//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

public class Lab02d
{
	public static void main( String[] args )
   {
		Cube test = new Cube();
	 	test.setSide(112);
	 	test.calculateSurfaceArea();
	 	test.print();

	 	//add more test cases
	 	
	 	
	 	
	 	
	}
}