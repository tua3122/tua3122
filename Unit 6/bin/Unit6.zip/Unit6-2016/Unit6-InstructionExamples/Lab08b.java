//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

public class Lab08b
{
	public static void main ( String[] args )
	{
		ForLoopDemo.runForLoop(2,90,5);

		//add more test cases
		
		
		
		
		
	}
}