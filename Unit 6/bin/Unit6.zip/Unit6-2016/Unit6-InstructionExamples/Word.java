//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class Word
{
	private String word;

	public Word()
	{


	}

	public Word(String s)
	{


	}

	public void setString(String s)
	{


	}

	public char getFirstChar()
	{
		return 0;
	}

	public char getLastChar()
	{
		return 0;
	}

	public String getBackWards()
	{
		String back="";





		return back;
	}

 	public String toString()
 	{
 		return "";
	}
}