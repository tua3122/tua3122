//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class LoopStats
{
	private int start, stop;

	public LoopStats()
	{


	}

	public LoopStats(int beg, int end)
	{


	}

	public void setNums(int beg, int end)
	{


	}

	public int getEvenCount()
	{
		int evenCount=0;




		return evenCount;
	}

	public int getOddCount()
	{
		int oddCount=0;





		return oddCount;
	}

	public int getTotal()
	{
		int total=0;




		return total;
	}
	
	public String toString()
	{
		return start + " " + stop;
	}
}