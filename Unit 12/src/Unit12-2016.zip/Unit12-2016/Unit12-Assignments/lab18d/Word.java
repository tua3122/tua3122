//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class Word implements Comparable<Word>
{
	private String word;

	public Word( String s )
	{


	}

	public int compareTo( Word rhs )
	{
		
		
		
		
		
		return 0;
	}

	public String toString()
	{
		return "";
	}
}