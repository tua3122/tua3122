//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class Word implements Comparable<Word>
{
	private String word;

	public Word( String s)
	{


	}

	private int numVowels()
	{
		String vowels = "AEIOUaeiou";
		int vowelCount=0;







		return vowelCount;
	}

	public int compareTo(Word rhs)
	{



	
		return -1;
	}

	public String toString()
	{
		return word;
	}
}