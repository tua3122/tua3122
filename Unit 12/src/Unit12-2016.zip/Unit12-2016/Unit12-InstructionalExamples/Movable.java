//� A+ Computer Science
// www.apluscompsci.com

//interface example

public interface Movable
{
	public void setPos( int x, int y);
	public void setX( int x );
	public void setY( int y );
}