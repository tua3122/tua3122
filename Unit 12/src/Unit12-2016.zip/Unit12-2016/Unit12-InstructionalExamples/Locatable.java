//� A+ Computer Science
// www.apluscompsci.com

//interface example

public interface Locatable
{
	public int getX();
	public int getY();
}